package com.cg.faculty.services;

import java.util.ArrayList;

import com.cg.faculty.beans.Session;
import com.cg.faculty.exceptions.SessionServicesDownException;

public interface FacultyServices {

	ArrayList<Session> getAllSessionDetails() throws SessionServicesDownException;
	
	Session getSessionDetails(int id) throws SessionServicesDownException;
	
	Session updateSessionDetails(Session session) throws SessionServicesDownException;
	
}
