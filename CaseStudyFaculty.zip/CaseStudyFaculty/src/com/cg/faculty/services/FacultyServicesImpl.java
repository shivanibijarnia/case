package com.cg.faculty.services;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.faculty.beans.Session;
import com.cg.faculty.daoservices.FacultyDAOServices;
import com.cg.faculty.exceptions.SessionServicesDownException;

@Component(value = "facultyServices")
public class FacultyServicesImpl implements FacultyServices {

	@Autowired
	private FacultyDAOServices daoServices;

	@Override
	public ArrayList<Session> getAllSessionDetails() throws SessionServicesDownException {
		return (ArrayList<Session>) daoServices.findAll();
	}

	@Override
	public Session getSessionDetails(int id) throws SessionServicesDownException {
		Session session = daoServices.findOne(id);
		if (session == null)
			throw new SessionServicesDownException("Session Details with Id " + id + " not found");
		return session;
	}

	@Transactional
	@Override
	public Session updateSessionDetails(Session session) throws SessionServicesDownException {
		return daoServices.save(session);
	}

}
